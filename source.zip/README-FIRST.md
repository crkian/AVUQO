# AVUQO v0.5 Control Centre shell restore

The previous rendering/security patches accidentally replaced the original
Control Centre visual shell with a bare children wrapper.

This patch restores:
- private AVUQO header
- owner/admin role badge
- return-to-consumer link
- Control Centre sidebar navigation
- page content frame
- dashboard card/table/pill styling
- responsive layout

It retains:
- server-side access control
- `await connection()`
- Suspense
- `export const instant = false`

No SQL changes are required.

Install:
1. Stop AVUQO.
2. Extract this ZIP directly over `C:\avuqo`.
3. Choose **Replace files in the destination**.
4. Run `npm.cmd run build`.
5. If successful, run `npm.cmd run dev`.
6. Commit to Git `main`.
