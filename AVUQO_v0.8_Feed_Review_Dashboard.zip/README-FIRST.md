# AVUQO v0.8: Feed Import Review Dashboard (incremental patch)

This patch builds on the WORKING AVUQO v0.8 Control Centre Feed Imports patch. It is **not** a complete project and does not include the earlier UploadForm, parser, or base migration. Install only after those have been deployed.

## What changes
- Replaces `app/control-centre/feed-imports/page.tsx` to show a clean dashboard for the latest import.
- Adds `ReviewDashboard.tsx` for search, validation/review filters, pagination (20 per page) and an inspection panel.
- Adds owner/admin API endpoint to save **internal** review decisions and notes only.
- Adds a SQL migration for review annotations and protected updates.
- Does NOT modify import data, merchant rights, public catalogue, affiliate URLs or publication controls.

## PowerShell (Windows)
Run in PowerShell, not in Supabase SQL Editor. Change the ZIP path if downloaded elsewhere.

```powershell
cd C:\avuqo
$backup = "C:\avuqo-backup-$(Get-Date -Format yyyyMMdd-HHmmss)"
Copy-Item C:\avuqo $backup -Recurse -Force
$zip = "$env:USERPROFILE\Downloads\AVUQO_v0.8_Feed_Review_Dashboard.zip"
Expand-Archive -LiteralPath $zip -DestinationPath C:\avuqo -Force
npm run build
```

**Supabase SQL Editor (NOT PowerShell):** Open `supabase/migrations/20261028010000_feed_import_review.sql` in your project, copy its SQL into Supabase SQL Editor, and run it before testing the review buttons.

If SQL policies already have the same name because of a previous partial run, stop and inspect before retrying. Don't delete any existing tables.

Local test (PowerShell):
```powershell
cd C:\avuqo
npm run dev
```
Open http://localhost:3000/control-centre/feed-imports and verify search, filters, record inspection, save/reload of review decisions. Then stop dev with Ctrl+C.

To deploy after the test passes:
```powershell
cd C:\avuqo
git status
git add app/control-centre/feed-imports/page.tsx app/control-centre/feed-imports/ReviewDashboard.tsx app/api/control-centre/feed-imports/review/route.ts supabase/migrations/20261028010000_feed_import_review.sql
git commit -m "AVUQO private feed review dashboard"
git push
```

## Limits and cautions
- The current dashboard loads up to 1000 records of the most recent import. This covers the 910-record AKKO pilot. Subsequent large feeds need database pagination.
- Review means the owner has inspected a record, **not** that merchant rights are verified or the product is publishable.
- No image previews are included because the earlier importer stores image presence, not a validated image URL.
- The feature uses the existing Supabase auth and user_roles setup; actual integration must be tested in your deployed environment.
